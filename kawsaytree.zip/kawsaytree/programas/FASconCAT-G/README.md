# FASconCAT-G
FASconCAT-G is written on Linux and runs on Windows PCs, Mac OS and Linux operating systems.
The program can be started directly via command line or through interactive menu options. Input files
coming from Windows CRLF line feeds should be converted into Unix (LF) line feeds. This can be done
in several editors (e.g., Bioedit or Notepad++). FASconCAT-G usually recognizes and converts these
files but not in every instance.
In order to run FASconCAT-G, open the terminal of your operating system and change directories to
the folder where FASconCAT-G and your input files are located. Type the name of your FASconCAT-G
version, followed either by a blank and your demand options in one row to start FASconCAT-G directly
or just hit <enter> to open the FASconCAT-G menu. Notice that all input files have to be located in the
FASconCAT-G home folder. To execute FASconCAT-G, a Perl interpreter must be installed on the current
run system. Linux and Mac systems typically come with an interpreter pre-installed while Windows users
will have to install a Perl interpreter (e.g., post). I recommend the ActivePerl interpreter.
