# =============================================================================
# Script Name: kawsaytree.sh
# Description: This script runs a phylogenetic analysis on a given 
#              mitochondrial PCGs FASTA input file.
# Author: sciruiz
# Date: 2025-07-15
# Version: 1.1.0
# Usage:
#   ./kawsaytree.sh -i sequence_list.txt -o output_prefix -d output_directory
#
# Required Arguments:
#   -i | --input       : Path to input FASTA file
# 
# Optional:
#   -h | --help        : Show this help message and exit
# =============================================================================

Folder structure:

kawsay
    |_ input/
        |_ mito_genes.txt               # List with the a prefix for each mitochondrial gene. 
    |_ programas/
        |_ FASconCAT-G/
        |_ FigTree v.1.4.4/
        |_ Gblocks_0.91b/
    |_ scripts/
        |_ custom_names.sh
        |_ fasta-gb2fasta.sh
        |_ onerow_mitogenome.sh
        |_ onerow.shape
        |_ rename.sh
        |_ separate_files.shape
        |_ seq_list.sh
    |_ kawsay.sh


Folder structure after running kawsay.sh:

kawsay
    |_ input/
        |_ mito_genes.txt               # List with the a prefix for each mitochondrial gene. 
    |_ programas/
        |_ FASconCAT-G/
        |_ FigTree v.1.4.4/
        |_ Gblocks_0.91b/
    |_ Data/
    |_ genes
    |_ aligned
    |_ gblocks
        |_ fasta-gb/
        |_ htm/
        |_ onerow/
            |_ concatenated             # Your file should be here, well-done!
    |_ kawsay.sh
