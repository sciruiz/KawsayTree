#!/bin/bash

# set -euo pipefail

exec > >(tee -i kawsay.log.txt)
exec 2>&1

# source scripts/utils.sh

#!/bin/bash

# =============================================================================
# Script Name: kawsaytree.sh
# Description: This script runs a phylogenetic analysis on a given 
#              mitochondrial PCGs FASTA input file.
# Author: sciruiz
# Date: 2025-07-15
# Version: 1.1.0
# Usage:
#   ./kawsaytree.sh -i sequence_list.txt -o output_prefix -d output_directory
#
# Required Arguments:
#   -i | --input       : Path to input FASTA file
# 
# Optional:
#   -h | --help        : Show this help message and exit
# =============================================================================

# Function to display help message
usage() {
    echo "==============================================================="
    echo "KawsayTree v1.1.0 - Phylogenetic Analysis Pipeline"
    echo "---------------------------------------------------------------"
    echo "Usage: $0 -i <input.fasta> -o <output_prefix> -d <output_directory>"
    echo
    echo "Required arguments:"
    echo "  -i, --input      Input accession codes (*.txt)"
    echo
    echo "Optional:"
    echo "  -h, --help       Display this help message"
    echo
    echo "Example:"
    echo "  ./kawsaytree.sh -i accessions.txt"
    echo "==============================================================="
    exit 0
}

# Parse arguments
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -i|--input) INPUT_FILE="$2"; shift ;;
        -h|--help) usage ;;
        *) echo "❌ Unknown parameter: $1" >&2; usage ;;
    esac
    shift
done

# Print startup message
echo "🔍 Running KawsayTree with:"
echo "  Input file    : $INPUT_FILE"
echo

echo "==== Running Kawsay Pipeline ===="

# Step 1: Fetch CDS
mkdir Data
echo "[1/3] Fetching coding sequences..."
bash scripts/seq_list.sh "$INPUT_FILE"  # Download the mitogenomes

mv cds_sequences.fasta Data/

bash scripts/onerow_mitogenome.sh       # Reformat the mitogenomes
bash scripts/rename.sh                  # Rename the .fasta file

# Modify custom names such as .COI, CO1, CytB, etc. 

# Find the patterns in your .fasta file with 
# grep '^>' renamed.fasta | sed 's/.*\(\.[^.]*\)$/\1/' | sort | uniq -c 

sed -i 's/\<COXIII\>/COX3/g' Data/renamed.fasta
sed -i 's/\<COXII\>/COX2/g' Data/renamed.fasta
sed -i 's/\<COXI\>/COX1/g' Data/renamed.fasta
sed -i 's/1_cds_AAT76635.1_1/ND1/' Data/renamed.fasta
sed -i 's/1_cds_AAT76636.1_2/ND2/' Data/renamed.fasta
sed -i 's/1_cds_AAT76637.1_3/CO1/' Data/renamed.fasta
sed -i 's/1_cds_AAT76638.1_4/CO2/' Data/renamed.fasta
sed -i 's/1_cds_AAT76639.1_5/ATP8/' Data/renamed.fasta
sed -i 's/1_cds_AAT76640.1_6/ATP6/' Data/renamed.fasta
sed -i 's/1_cds_AAT76641.1_7/CO3/' Data/renamed.fasta
sed -i 's/1_cds_AAT76642.1_8/ND3/' Data/renamed.fasta
sed -i 's/1_cds_AAT76643.1_9/ND4L/' Data/renamed.fasta
sed -i 's/1_cds_AAT76644.1_10/ND4/' Data/renamed.fasta
sed -i 's/1_cds_AAT76645.1_11/ND5/' Data/renamed.fasta
sed -i 's/1_cds_AAT76646.1_12/ND6/' Data/renamed.fasta
sed -i 's/1_cds_AAT76647.1_13/CYTB/' Data/renamed.fasta
sed -i 's/cox3/COX3/' Data/renamed.fasta
sed -i 's/CO1/COX1/' Data/renamed.fasta
sed -i 's/CO2/COX2/' Data/renamed.fasta
sed -i 's/CO3/COX3/' Data/renamed.fasta

mkdir genes
bash scripts/separate_files.sh          # Separar los PCGs
bash scripts/custom_name.sh             # Uniformizar el nombre

# Step 2: Align Sequences
echo "[2/3] Aligning sequences..."
mkdir aligned

#Run MAFFT
for i in genes/*.fasta; do mafft --quiet "$i" > "aligned/$(basename "${i%.fasta}").aligned.fasta"; done

for file in aligned/*.fasta; do sed -i 's/^\(>[^.]*\)\..*/\1/' "$file"; done
for file in aligned/*.fasta; do sed -i 's/_//g' "$file"; done

# GBLOCKS
mkdir gblocks
bash scripts/onerow.sh       # Reformat to one_line to run in gblocks
cd gblocks
for file in *.aligned.fasta; do ../programas/Gblocks_0.91b/Gblocks "$file" -t=d -b5=n -p=y; done

mkdir fasta-gb/ html/ 
mv *.fasta-gb fasta-gb/
mv *.htm html/

cd ..

bash scripts/fasta-gb2fasta.sh       # Reformat fasta-gb to run fasta

# Concatenar
cd gblocks/onerow/
perl ../../programas/FASconCAT-G/FASconCAT-G_v1.06.1.pl -p -p -s

mkdir concatenated
mv FcC_* concatenated/

# Step 3: Build Tree
echo "[3/3] Building phylogenetic tree..." 

#comand for iqtree3
iqtree2 -s concatenated/FcC_supermatrix.phy -m MFP -B 1000

echo "Pipeline finished! look for the *.treefile (path: gblocks/onerow/) to visualize it with FigTree or any another external software."