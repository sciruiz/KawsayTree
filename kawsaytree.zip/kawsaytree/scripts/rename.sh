#rename the mitogenomic names
#delete repetitive information
sed -E 's/^>lcl\|/>/; s/ \[locus_tag=.*//; s/[\[\]]//g' Data/onerow_mito.fasta > Data/temp.fasta
#delete unncesary information and format it to >Accesion_Code_ND1
sed -E 's/^>([^.]+)\.[0-9]+_cds_[^ ]+ \[gene=([^]]+)\]/>\1.\2/' Data/temp.fasta > Data/temp1.fasta
#delete other patterns
sed '/^>/ s/ .*$//' Data/temp1.fasta > Data/renamed.fasta
rm Data/temp.fasta Data/temp1.fasta