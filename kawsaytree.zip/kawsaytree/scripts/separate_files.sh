total=$(wc -l < input/mito_genes.txt)
count=0

while read -r gene; do
  count=$((count + 1))
  
  echo "Processing gene $count of $total: $gene"
  
  grep -n -w "$gene" Data/renamed.fasta | cut -d: -f1 | while read -r line_num; do
    sed -n "${line_num},$((line_num+1))p" Data/renamed.fasta >> "genes/${gene}.fasta"
  done

  match_count=$(grep -c "^>" "genes/${gene}.fasta")
  echo "Found $match_count sequences"
done < input/mito_genes.txt
