#!/bin/bash

export LC_ALL=C
export LANG=C

# Check if input file is provided
if [[ -z "$1" ]]; then
    echo "Usage: $0 <accession_file.txt>"
    exit 1
fi

INPUT_FILE="$1"
OUTPUT_FILE="cds_sequences.fasta"

# Clear output file if it exists
> "$OUTPUT_FILE"

# Read each accession and fetch CDS
while read -r ACC; do
    if [[ -n "$ACC" ]]; then
        echo "Fetching CDS for $ACC..."
        efetch -db nucleotide -id "$ACC" -format fasta_cds_na >> "$OUTPUT_FILE"
    fi
done < "$INPUT_FILE"
